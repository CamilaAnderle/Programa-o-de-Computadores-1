#include "entrada.h"
#include <stdio.h>

// recebe o tabuleiro inicial do jogo da velha
void entrada(FILE *arquivo_entrada, char matriz[][4]) {
  for (int i = 0; i < 3; i++) {
    fscanf(arquivo_entrada, "%s", matriz[i]);
  }
}