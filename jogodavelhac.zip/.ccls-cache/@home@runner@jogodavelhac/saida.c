#include "saida.h"
#include "tratamentodeerros.h"
#include <stdio.h>

// realiza a impressão da matriz, no arquivo de saída, quando o 'O' ganhar no processamento
void imprime(FILE *arquivo_saida, char matriz[][4]) {
  for (int i = 0; i < 3; i++) {
    fprintf(arquivo_saida, "%s\n", matriz[i]);
  }
  fprintf(arquivo_saida, "\n");
}
