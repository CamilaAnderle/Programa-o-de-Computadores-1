#include "tratamentodeerros.h"
#include "entrada.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// funcao que testa a quantidade de arquivos
void testa_parametros(int argc) {
  if (argc != 3) {
    printf("Uso: ./executavel <arquivo_entrada.txt> <arquivo_saida.txt>");
    exit(0);
  }
}

// funcao que testa se o arquivo inserido esta nulo
void testa_abertura(FILE *arquivo_entrada, const char *arquivo, const char *mode) {
  if (arquivo_entrada == NULL) {
    printf("Falha em abrir o arquivo %s com o modo %s\n", arquivo, mode);
    exit(0);
  }
}