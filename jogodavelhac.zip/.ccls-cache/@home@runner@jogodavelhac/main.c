#include "entrada.h"
#include "processamento.h"
#include "saida.h"
#include "tratamentodeerros.h"
#include <stdio.h>

int main(int argc, char *argv[]) {

  // realiza o tratamento de erros
  testa_parametros(argc);
  FILE *arquivo_entrada = fopen(argv[1], "r"), *arquivo_saida = fopen(argv[2], "w");
  testa_abertura(arquivo_entrada, argv[1], "r");

  char matriz[3][4];
	
  // realiza a leitura da configuração inicial do jogo da velha
  entrada(arquivo_entrada, matriz);

  troca_o(arquivo_saida, matriz);

  return 0;
}