#include "entrada.h"
#include "saida.h"
#include <stdio.h>

void troca_x(FILE *arquivo_saida, char matriz[][4]);
void troca_o(FILE *arquivo_saida, char matriz[][4]);

// testa se o 'X' ou o 'O' ganhou
int testa_ganhou(char matriz[][4]) {
  for (int i = 0; i < 3; i++) {
    // testa na horizontal se o 'O' ganhou
    if (matriz[i][0] == 'O' && matriz[i][1] == 'O' && matriz[i][2] == 'O')
      return 1;
    // testa na vertical se o 'X' ganhou
    if (matriz[i][0] == 'X' && matriz[i][1] == 'X' && matriz[i][2] == 'X')
      return 2;
    // testa na vertical se o 'O' ganhou
    if (matriz[0][i] == 'O' && matriz[1][i] == 'O' && matriz[2][i] == 'O')
      return 1;
    // testa na vertical se o 'X' ganhou
    if (matriz[0][i] == 'X' && matriz[1][i] == 'X' && matriz[2][i] == 'X')
      return 2;
  }
  // testa na diagonal se o 'O' ganhou
  if (matriz[0][0] == 'O' && matriz[1][1] == 'O' && matriz[2][2] == 'O')
    return 1;
  if (matriz[0][2] == 'O' && matriz[1][1] == 'O' && matriz[2][0] == 'O')
    return 1;
  // testa na diagonal se o 'X' ganhou
  if (matriz[0][0] == 'X' && matriz[1][1] == 'X' && matriz[2][2] == 'X')
    return 2;
  if (matriz[0][2] == 'X' && matriz[1][1] == 'X' && matriz[2][0] == 'X')
    return 2;

  return 0;
}

// testa se o tabuleiro ja esta completo
int testa_completo(FILE *arquivo_saida, char matriz[][4]) {
  int completo = 1;
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      if (matriz[i][j] == 'B')
        completo = 0;
    }
  }
  return completo;
}

// troca o espaço em branco pelo 'X' e imprime quando o 'O' ganhar
void troca_x(FILE *arquivo_saida, char matriz[][4]) {

  // testa se o 'O' ganhou
  if (testa_ganhou(matriz) == 1) {
    // se o 'O' ganhou, imprime a matriz
    imprime(arquivo_saida, matriz);
    return;
  }

  // testa se o tabuleiro está completo e, caso esteja, encerra
  if (testa_completo(arquivo_saida, matriz) == 1) {
    return;
  }

  // testa se o 'X' ganhou e, caso tenha ganhado, encerra
  if (testa_ganhou(matriz) == 2)
    return;

  // troca o espaço em branco por 'X'
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      if (matriz[i][j] == 'B') {
        matriz[i][j] = 'X';
        // chama a função troca_o para trocar o próximo espaço em branco por 'O'
        troca_o(arquivo_saida, matriz);
        matriz[i][j] = 'B';
      }
    }
  }
}

// troca o espaço em branco por 'O' e imprime quando o 'O' ganhar
void troca_o(FILE *arquivo_saida, char matriz[][4]) {

  // testa se o 'O' ganhou
  if (testa_ganhou(matriz) == 1) {
    // se o 'O' ganhou, imprime a matriz
    imprime(arquivo_saida, matriz);
    return;
  }
  // testa se o tabuleiro está completo e, caso esteja, encerra
  if (testa_completo(arquivo_saida, matriz) == 1) {
    return;
  }
  // testa se o 'X' ganhou e, caso tenha ganhado, encerra
  if (testa_ganhou(matriz) == 2)
    return;

  // realiza a troca do espaço em branco por 'O'
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      if (matriz[i][j] == 'B') {
        matriz[i][j] = 'O';
        // chama a função troca_x para trocar o próximo espaço em branco por 'X'
        troca_x(arquivo_saida, matriz);
        matriz[i][j] = 'B';
      }
    }
  }
}
