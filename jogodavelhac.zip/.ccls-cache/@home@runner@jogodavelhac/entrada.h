#ifndef ENTRADA_H
#define ENTRADA_H
#include <stdio.h>

void entrada(FILE *arquivo_entrada, char matriz[][4]);

#endif