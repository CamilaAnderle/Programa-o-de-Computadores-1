#ifndef PROCESSAMENTO_H
#define PROCESSAMENTO_H
#include <stdio.h>

void troca_o(FILE *arquivo_saida, char matriz[][4]);

#endif