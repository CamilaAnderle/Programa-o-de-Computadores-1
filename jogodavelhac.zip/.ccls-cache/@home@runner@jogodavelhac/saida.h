#ifndef SAIDA_H
#define SAIDA_H
#include <stdio.h>

void imprime(FILE *arquivo_saida, char matriz[][4]);

#endif