#include "entrada.h"
#include <stdio.h>
#include <string.h>

// funcao que zera o registro de equipes para calcular as informacoes em organizacao
void zera(int n, equipes eqp[]) {
  for (int i = 0; i < n; i++) {
    eqp[i].pos_final = 0;
    eqp[i].total_de_pontos = 0;
    eqp[i].numero_de_vitorias = 0;
    eqp[i].saldo_de_gols = 0;
    eqp[i].gols_a_favor = 0;
    eqp[i].gols_contra = 0;
  }
}

// esta funcao compara se determinado time do registro equipe eqp[] e o  time do
// reg_jogos jpr[] de determinado jogo sao iguais
int busca_time(equipes *eqp, int n, char *string) {
  int idx = -1;
  for (int i = 0; i < n; i++) {
    if (strcmp(eqp[i].nome_equipe, string) == 0) {
      idx = i;
    }
  }
  return idx;
}

// esta funcao analisa as informacoes dos jogos e armazena as informacoes dos
// pontos, vitorias, gols... no registro equipe eqp[] para posterior ordenacao
void organizacao(equipes *eqp, reg_jogos *jpr, int n, int jogos_por_rodadas, int rodadas) {
  for (int j = 0; j < jogos_por_rodadas; j++) {
    int idx_time1 = busca_time(eqp, n, jpr[j].time1);
    int idx_time2 = busca_time(eqp, n, jpr[j].time2);
    // empate entre os times
    if (jpr[j].gols_time1 == jpr[j].gols_time2) {
      // numero de jogos
      eqp[idx_time1].numero_de_jogos = rodadas;
      eqp[idx_time2].numero_de_jogos = rodadas;
      // total de pontos
      eqp[idx_time1].total_de_pontos += 1;
      eqp[idx_time2].total_de_pontos += 1;
      // gols a favor
      eqp[idx_time1].gols_a_favor += jpr[j].gols_time1;
      eqp[idx_time2].gols_a_favor += jpr[j].gols_time2;
      // gols contra
      eqp[idx_time1].gols_contra += jpr[j].gols_time2;
      eqp[idx_time2].gols_contra += jpr[j].gols_time1;
    }
    // vitoria do time 1
    else if (jpr[j].gols_time1 > jpr[j].gols_time2) {
      // numero de jogos
      eqp[idx_time1].numero_de_jogos = rodadas;
      eqp[idx_time2].numero_de_jogos = rodadas;
      // total de pontos
      eqp[idx_time1].total_de_pontos += 3;
      // vitorias
      eqp[idx_time1].numero_de_vitorias += 1;
      // gols a favor
      eqp[idx_time1].gols_a_favor += jpr[j].gols_time1;
      eqp[idx_time2].gols_a_favor += jpr[j].gols_time2;
      // gols contra
      eqp[idx_time1].gols_contra += jpr[j].gols_time2;
      eqp[idx_time2].gols_contra += jpr[j].gols_time1;

    }
    // vitoria do time 2
    else {
      // numero de jogos
      eqp[idx_time1].numero_de_jogos = rodadas;
      eqp[idx_time2].numero_de_jogos = rodadas;
      // total de pontos
      eqp[idx_time2].total_de_pontos += 3;
      // vitorias
      eqp[idx_time2].numero_de_vitorias += 1;
      // gols a favor
      eqp[idx_time1].gols_a_favor += jpr[j].gols_time1;
      eqp[idx_time2].gols_a_favor += jpr[j].gols_time2;
      // gols contra
      eqp[idx_time1].gols_contra += jpr[j].gols_time2;
      eqp[idx_time2].gols_contra += jpr[j].gols_time1;
    }
  }
  // saldo de gols de todos os times
  for (int i = 0; i < n; i++) {
    eqp[i].saldo_de_gols = eqp[i].gols_a_favor - eqp[i].gols_contra;
  }
}
