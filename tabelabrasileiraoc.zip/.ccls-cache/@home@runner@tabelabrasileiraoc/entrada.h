#ifndef ENTRADA_H
#define ENTRADA_H
#include <stdio.h>

typedef struct reg_jogos {
  char time1[21];
  char x[2];
  int gols_time1;
  char time2[21];
  int gols_time2;
} reg_jogos;

typedef struct equipes {
  int pos_final;
  char nome_equipe[21];
  int total_de_pontos;
  int numero_de_jogos;
  int numero_de_vitorias;
  int saldo_de_gols;
  int gols_a_favor;
  int gols_contra;
} equipes;

void le_rodadas(FILE *arquivo_entrada, int n, equipes eqp[], int jogos_por_rodadas, reg_jogos jpr[]);
void le_equipes(FILE *arquivo_entrada, equipes eqp[], int n);

#endif