#ifndef ORDENACAO_H
#define ORDENACAO_H
#include "entrada.h"

void ordenacao(equipes eqp[], int n);

#endif 