#ifndef TRATAMENTODEERROS_H
#define TRATAMENTODEERROS_H
#include <stdio.h>

  void testa_parametros(int argc);
  void testa_abertura(FILE *arquivo_entrada, const char *arquivo, const char *mode);

#endif