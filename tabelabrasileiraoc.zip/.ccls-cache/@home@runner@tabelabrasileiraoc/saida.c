#include "ordenacao.h"
#include <stdio.h>

// imprime a tabela de classificacao das equipes, da melhor colocada para a pior
void saida(FILE *arquivo_saida, equipes eqp[], int n) {
  for (int i = 0; i < n; i++) {
    fprintf(arquivo_saida, "%d %s %d %d %d %d %d %d\n", i + 1,
            eqp[i].nome_equipe, eqp[i].total_de_pontos, eqp[i].numero_de_jogos,
            eqp[i].numero_de_vitorias, eqp[i].saldo_de_gols,
            eqp[i].gols_a_favor, eqp[i].gols_contra);
  }
}