#include "processamento.h"
#include <stdio.h>

// ordena as equipes da melhor colocada para a pior
void ordenacao(equipes eqp[], int n) {
  equipes aux;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n - 1; j++) {
      // o primeiro criterio: total de pontos
      if (eqp[j].total_de_pontos < eqp[j + 1].total_de_pontos) {
        aux = eqp[j];
        eqp[j] = eqp[j + 1];
        eqp[j + 1] = aux;
      }
      // o segundo criterio: numero de vitorias
      else if (eqp[j].total_de_pontos == eqp[j + 1].total_de_pontos) {
        if (eqp[j].numero_de_vitorias < eqp[j + 1].numero_de_vitorias) {
          aux = eqp[j];
          eqp[j] = eqp[j + 1];
          eqp[j + 1] = aux;
        }
        // o terceiro criterio: saldo de gols
        else if (eqp[j].numero_de_vitorias == eqp[j + 1].numero_de_vitorias) {
          if (eqp[j].saldo_de_gols < eqp[j + 1].saldo_de_gols) {
            aux = eqp[j];
            eqp[j] = eqp[j + 1];
            eqp[j + 1] = aux;
          }
          // o quarto criterio: gols a favor
          else if (eqp[j].saldo_de_gols == eqp[j + 1].saldo_de_gols) {
            if (eqp[j].gols_a_favor < eqp[j + 1].gols_a_favor) {
              aux = eqp[j];
              eqp[j] = eqp[j + 1];
              eqp[j + 1] = aux;
            }
            // o quinto criterio: gols a contra
            else if (eqp[j].gols_a_favor == eqp[j + 1].gols_a_favor) {
              if (eqp[j].gols_contra > eqp[j + 1].gols_contra) {
                aux = eqp[j];
                eqp[j] = eqp[j + 1];
                eqp[j + 1] = aux;
              }
            }
          }
        }
      }
    }
  }
}
