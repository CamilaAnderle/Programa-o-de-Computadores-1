#include "entrada.h"
#include <stdio.h>

// funcao que le o nome das equipes e os salva em um registro
void le_equipes(FILE *arquivo_entrada, equipes eqp[], int n) {
  for (int i = 0; i < n; i++) {
    fscanf(arquivo_entrada, "%s", eqp[i].nome_equipe);
  }
	fscanf(arquivo_entrada, "%*s");
}

// funcao que le as informacoes de cada rodada
void le_rodadas(FILE *arquivo_entrada, int n, equipes eqp[], int jogos_por_rodadas, reg_jogos jpr[]) {
  // le as informacoes dos jogos em cada rodada e os salva em um registro(reg_jogos jpr[])
  for (int j = 0; j < jogos_por_rodadas; j++) {
    fscanf(arquivo_entrada, "%s %d %*s %d %s", jpr[j].time1, &jpr[j].gols_time1, &jpr[j].gols_time2, jpr[j].time2);
  }
	// le o separador ---
  fscanf(arquivo_entrada, "%*s");
}
