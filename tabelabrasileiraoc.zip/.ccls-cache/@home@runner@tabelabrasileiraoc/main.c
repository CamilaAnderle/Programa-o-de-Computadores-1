#include "entrada.h"
#include "processamento.h"
#include "saida.h"
#include "tratamentodeerros.h"
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
	
  testa_parametros(argc);
  FILE *arquivo_entrada = fopen(argv[1], "r"), *arquivo_saida = fopen(argv[2], "w");
  testa_abertura(arquivo_entrada, argv[1], "r");
	
  // numero de times que estao disputando o campeonato brasileiro
  int n;
  fscanf(arquivo_entrada, "%d", &n);
	
  // quantidades de jogos em cada rodada
  int jogos_por_rodadas = n / 2;
	
  // quantidade de rodadas
  int rodadas = 2 * (n - 1);
	
  // registro que recebe as equipes e as informacoes contidas na tabela de saida
  equipes eqp[20];
  zera(n, eqp);
	
  // registro que armazena as informacoes dos jogos de cada rodada
  reg_jogos jpr[50];
  le_equipes(arquivo_entrada, eqp, n);
	
  /* este for realiza a leitura das informacoes dos jogos no modulo de entrada a
   * partir da funcao le_rodadas e depois as organiza no modulo de processamento
   * atraves da funcao organizacao */
  for (int i = 0; i < rodadas; i++) {
    le_rodadas(arquivo_entrada, n, eqp, jogos_por_rodadas, jpr);
    organizacao(eqp, jpr, n, jogos_por_rodadas, rodadas);
  }
	
  ordenacao(eqp, n);
  saida(arquivo_saida, eqp, n);
	
  return 0;
}