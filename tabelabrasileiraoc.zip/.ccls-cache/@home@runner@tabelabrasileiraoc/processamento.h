#ifndef PROCESSAMENTO_H
#define PROCESSAMENTO_H
#include "entrada.h"

  void organizacao(equipes *eqp, reg_jogos *jpr, int n, int jogos_por_rodadas, int rodadas);
  void zera (int n, equipes eqp[]);

#endif