#ifndef SAIDA_H
#define SAIDA_H
#include "ordenacao.h"
#include <stdio.h>

void saida(FILE *arquivo_saida,equipes eqp[], int n );

#endif