#ifndef PROCESSAMENTO_H
#define PROCESSAMENTO_H

void comparacao(char palavras[][81], char cacapalavras[][81], int i, int j,
                int tamanho, int y, int *pont_controle);
void processamento(int quant_palavras, int dimensao, char palavras[][81],
                   char cacapalavras[81][81]);

#endif
