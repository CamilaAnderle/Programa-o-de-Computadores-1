#include "entrada.h"
#include <stdio.h>
#include <string.h>

// função que lê as palavras
void le_palavras(int quant_palavras, char palavras[][81]) {
  for (int i = 0; i < quant_palavras; i++) {
    scanf("%s", palavras[i]);
  }
}

// função que lê o caça palavras
void le_cacapalavras(int dimensao, char cacapalavras[][81]) {
  for (int i = 0; i < dimensao; i++) {
    scanf("%s", cacapalavras[i]);
  }
}
