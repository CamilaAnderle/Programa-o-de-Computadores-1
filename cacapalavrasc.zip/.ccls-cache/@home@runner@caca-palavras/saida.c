#include "saida.h"
#include <stdio.h>
#include <string.h>

// essa funcao realiza a impressao das coordenadas de cada palavra
void saida(int matriz_saida[2][81], int tamanho) {
  // organiza a ordem das coordenadas da menor coluna para a maior coluna
  if (matriz_saida[0][0] > matriz_saida[0][1]) {
    for (int i = (tamanho - 1); i >= 0; i--) {
      printf(" (%d,%d)", matriz_saida[0][i], matriz_saida[1][i]);
    }
  }
  // organiza a ordem das coordenadas da menor coluna e menor linha para a maior
  // coluna e maior linha
  else if (matriz_saida[0][0] == matriz_saida[0][1] &&
           matriz_saida[1][0] > matriz_saida[1][1]) {
    for (int i = (tamanho - 1); i >= 0; i--) {
      printf(" (%d,%d)", matriz_saida[0][i], matriz_saida[1][i]);
    }
  } else {
    // apenas imprime caso as linhas e colunas ja estejam da menor para a maior
    for (int i = 0; i < tamanho; i++) {
      printf(" (%d,%d)", matriz_saida[0][i], matriz_saida[1][i]);
    }
  }
  printf("\n");
}