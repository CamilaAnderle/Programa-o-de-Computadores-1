#ifndef ENTRADA_H
#define ENTRADA_H

void le_palavras(int quant_palavras, char palavras[][81]);
void le_cacapalavras(int dimensao, char cacapalavras[][81]);

#endif
