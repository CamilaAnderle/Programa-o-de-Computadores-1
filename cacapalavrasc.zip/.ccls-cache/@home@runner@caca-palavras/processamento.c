#include "processamento.h"
#include "saida.h"
#include <stdio.h>
#include <string.h>

// funcao que procura as palavras em todas as direcoes
void comparacao(char palavras[][81], char cacapalavras[][81], int i, int j,
                int tamanho, int y, int *pont_controle) {
  // Matriz que recebe as coordenadas
  int matriz_saida[2][81];
  // Compara letras na horizontal da esquerda para a direita
  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i][j + k]) {
      matriz_saida[0][k] = i;
      matriz_saida[1][k] = j + k;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }

  // Compara letras na vertical de cima para baixo

  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i + k][j]) {
      matriz_saida[0][k] = i + k;
      matriz_saida[1][k] = j;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }

  // Compara letras na diagonal de cima para baixo da esquerda para a direita

  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i + k][j + k]) {
      matriz_saida[0][k] = i + k;
      matriz_saida[1][k] = j + k;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }

  // Compara letras na diagonal de baixo para cima da esquerda para a direita

  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i - k][j + k]) {
      matriz_saida[0][k] = i - k;
      matriz_saida[1][k] = j + k;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }

  // Compara letras na diagonal de baixo para cima da direita para a esquerda

  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i - k][j - k]) {
      matriz_saida[0][k] = i - k;
      matriz_saida[1][k] = j - k;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }

  // Compara letras na diagonal de cima para baixo da direita para a esquerda

  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i + k][j - k]) {
      matriz_saida[0][k] = i + k;
      matriz_saida[1][k] = j - k;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }

  // Compara letras na horizontal da direita para a esquerda

  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i][j - k]) {
      matriz_saida[0][k] = i;
      matriz_saida[1][k] = j - k;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }

  // Compara letras na vertical de baixo para cima

  for (int k = 0; k < tamanho && *pont_controle == 1; k++) {
    if (palavras[y][k] == cacapalavras[i - k][j]) {
      matriz_saida[0][k] = i - k;
      matriz_saida[1][k] = j;
    }
    // Sai do laco caso ache uma letra diferente e passa para a proxima
    // comparacao
    else
      break;
    // Retoma a matriz saida quando atinge o tamanho da palavra
    if (k + 1 == tamanho) {
      saida(matriz_saida, tamanho);
      *pont_controle = 0;
      break;
    }
  }
}

void processamento(int quant_palavras, int dimensao, char palavras[][81],
                   char cacapalavras[81][81]) {
  // variavel utilizada para interromper a funcao comparacao quando encontra uma
  // palavra, para evitar encontrar a mesma palavra duas vezes
  int controle;
  int *pont_controle = &controle;
  // for que realiza a busca de cada palavra
  for (int y = 0; y < quant_palavras; y++) {
    controle = 1;
    printf("%s", palavras[y]);
    int tamanho = strlen(palavras[y]);
    // quando acha um carater igual na palavra e no caca palavras, entra no if
    // para verificar se os proximos caracteres tambem coindicem
    for (int i = 0; i < dimensao && controle == 1; i++) {
      for (int j = 0; j < dimensao && controle == 1; j++) {
        if (palavras[y][0] == cacapalavras[i][j]) {
          comparacao(palavras, cacapalavras, i, j, tamanho, y, pont_controle);
        }
      }
    }
  }
}
