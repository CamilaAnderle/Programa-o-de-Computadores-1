#ifndef SAIDA_H
#define SAIDA_H

void saida(int matriz_saida[2][81], int tamanho);

#endif