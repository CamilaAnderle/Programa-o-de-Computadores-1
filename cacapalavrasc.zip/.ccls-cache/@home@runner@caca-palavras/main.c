#include "entrada.h"
#include "processamento.h"
#include <stdio.h>
#include <string.h>

int main(void) {
  // le a dimensao da matriz quadrada e a quantidade de palavras a serem
  // encontradas na matriz
  int dimensao, quant_palavras;
  scanf("%d %d", &dimensao, &quant_palavras);
  // string que recebe as palavras
  char palavras[quant_palavras][81];
  le_palavras(quant_palavras, palavras);
  // string que recebe o caca palavras
  char cacapalavras[dimensao][81];
  le_cacapalavras(dimensao, cacapalavras);
  // matriz que recebe as coordenadas das palavras no caca palavras
  // int matriz_saida[2][81];
  // funcao que realiza a busca das palavras em todas as direcoes
  processamento(quant_palavras, dimensao, palavras, cacapalavras);
}
